package DoWhileLoop;

public class Example1 {
    public static void main(String[] args) {
        int i = 1;
        do {
            System.out.println("Hello");
            i++;
        } while (i<=5);
        System.out.println("Loop finished.");
    }
}
