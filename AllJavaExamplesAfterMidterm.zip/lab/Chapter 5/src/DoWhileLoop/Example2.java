package DoWhileLoop;

public class Example2 {
    public static void main(String[] args) {
        int i = 1;
        do {
            System.out.println(i);
            i++;
        } while (i<=100);
        System.out.println("Loop finished.");
    }
}
