package DoWhileLoop;

import java.util.Scanner;

public class HomeWork5 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int sum = 0;
        do {
            System.out.print("Enter an integer: ");
            int integer = input.nextInt();
            sum+= integer;
            System.out.println(sum);
        } while (sum<100);
        System.out.println("Loop finished.");
    }
}
