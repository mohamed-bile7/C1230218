package ForLoop;

public class Example3 {
    public static void main(String[] args) {
        for (int i = 100; i>=1; i--){
            System.out.println(i);
        }
        System.out.println("Loop finished.");
    }
}
