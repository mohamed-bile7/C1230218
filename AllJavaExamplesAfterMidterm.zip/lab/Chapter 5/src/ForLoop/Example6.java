package ForLoop;

public class Example6 {
    public static void main(String[] args) {
        for (int i = 100; i>=1; i-= 2){
            System.out.println(i);
        }
        System.out.println("Loop finished.");
    }
}
