package ForLoop;

import java.util.Scanner;

public class HomeWork5 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int sum = 0;
        for (; sum<100;){
            System.out.print("Enter an integer: ");
            int integer = input.nextInt();
            sum+= integer;
            System.out.println(sum);
        }
        System.out.println("Loop finished.");
    }
}
