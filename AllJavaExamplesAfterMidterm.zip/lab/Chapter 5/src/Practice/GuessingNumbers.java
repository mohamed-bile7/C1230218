package Practice;

import java.util.Scanner;

public class GuessingNumbers {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int secretNumber = (int) (Math.random() *101);
        int guess;

        while (true){
            System.out.print("Guess a number between 0 and 100: ");
            guess = input.nextInt();

            if (guess < secretNumber){
                System.out.println("Too low! Try again.");
            } else if (guess > secretNumber) {
                System.out.println("Too high! Try again.");
            } else {
                System.out.println("Correct! the number was: "+ secretNumber );
                break;
            }

        }
    }
}
