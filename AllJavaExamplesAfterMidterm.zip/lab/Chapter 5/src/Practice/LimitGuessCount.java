package Practice;
import java.util.Scanner;

public class LimitGuessCount {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int secretNumber = (int) (Math.random() *101);
        int guess;
        int guessCount = 1;

        while (guessCount <=5){
            System.out.print("Guess a number between 0 and 100: ");
            guess = input.nextInt();
            guessCount++;

            if (guess < secretNumber){
                System.out.println("Too low! Try again.");
            } else if (guess > secretNumber) {
                System.out.println("Too high! Try again.");
            } else {
                System.out.println("Correct! the number was: "+ secretNumber );
                System.out.println("You took " + guessCount + " guesses!");
                break;
            }
        }
    }
}
