package WhileLoop;

public class Example3 {
    public static void main(String[] args) {
        int i = 100;
        while (i >=1){
            System.out.println(i);
            i--;
        }
        System.out.println("Loop finished.");
    }
}
