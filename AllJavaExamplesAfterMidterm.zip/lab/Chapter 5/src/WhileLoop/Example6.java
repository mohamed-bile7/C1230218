package WhileLoop;

public class Example6 {
    public static void main(String[] args) {
        int i = 100;
        while (i >=1){
            System.out.println(i);
            i -= 2;
        }
        System.out.println("Loop finished.");
    }
}
