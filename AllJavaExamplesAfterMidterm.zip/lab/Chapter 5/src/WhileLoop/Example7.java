package WhileLoop;

public class Example7 {
    public static void main(String[] args) {
        int i = 99;
        while (i >=1){
            System.out.println(i);
            i -= 2;
        }
        System.out.println("Loop finished.");
    }
}
