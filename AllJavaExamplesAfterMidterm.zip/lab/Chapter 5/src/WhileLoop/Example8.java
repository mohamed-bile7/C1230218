package WhileLoop;

public class Example8 {
    public static void main(String[] args) {
        int i = 1;
        while (i <=10){
            System.out.println("1 x "+ i +" = "+ i);
            i++;
        }
        System.out.println("Loop finished.");
    }
}
