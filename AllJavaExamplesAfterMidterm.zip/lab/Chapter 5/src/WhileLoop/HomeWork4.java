package WhileLoop;

public class HomeWork4 {
    public static void main(String[] args) {
        int i = 100;
        while (i>= 1){
            if (i % 2 == 0){
                System.out.println(i);
            }
            i--;
        }
        System.out.println("Loop finished.");
    }
}
