package Homework;

public class Homework1 {
    public static void main(String[] args) {
        MyDetails("Mohamed", 25, 911);
    }
    public static void MyDetails(String name, int age, int mobileNumber) {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Mobile Number: " + mobileNumber);
    }
}
