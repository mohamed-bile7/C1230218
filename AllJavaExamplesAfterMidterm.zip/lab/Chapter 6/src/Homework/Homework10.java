package Homework;

public class Homework10 {
    public static void main(String[] args) {
        printNumbersAndTotal();
    }

    public static void printNumbersAndTotal() {
        int total = 0;
        System.out.println("Numbers from 1 to 10:");
        for (int i = 1; i <= 10; i++) {
            System.out.print(i + " ");
            total += i;
        }
        System.out.println("\nTotal: " + total);
    }
}