package Homework;

public class Homework2 {
    public static void main(String[] args) {
        sum(10, 5);
    }

    public static void sum(int num1, int num2) {
        System.out.println("Sum: " + (num1 + num2));
    }
}