package Homework;

public class Homework3 {
    public static void main(String[] args) {
        Difference(20, 8);
    }

    public static void Difference(int num1, int num2) {
        System.out.println("Difference: " + (num1 - num2));
    }
}