package Homework;

public class Homework4 {
    public static void main(String[] args) {
        Product(7, 6);
    }

    public static void Product(int num1, int num2) {
        System.out.println("Product: " + (num1 * num2));
    }
}