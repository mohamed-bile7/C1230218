package Homework;

public class Homework5 {
    public static void main(String[] args) {
        Division(15.0, 3.0);
        Division(10.0, 0.0); // Example of division by zero
    }

    public static void Division(double num1, double num2) {
        if (num2 == 0) {
            System.out.println("Cannot divide by zero!");
        } else {
            System.out.println("Division: " + (num1 / num2));
        }
    }
}