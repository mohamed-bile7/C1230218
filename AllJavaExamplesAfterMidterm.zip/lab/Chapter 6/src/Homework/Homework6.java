package Homework;

public class Homework6 {
    public static void main(String[] args) {
        Maximum(25, 12);
    }

    public static void Maximum(int num1, int num2) {
        System.out.println("Maximum: " + Math.max(num1, num2));
    }
}