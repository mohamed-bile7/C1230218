package Homework;

public class Homework7 {
    public static void main(String[] args) {
        Minimum(4, 18);
    }

    public static void Minimum(int num1, int num2) {
        System.out.println("Minimum: " + Math.min(num1, num2));
    }
}