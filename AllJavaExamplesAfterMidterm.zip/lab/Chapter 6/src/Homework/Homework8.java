package Homework;

public class Homework8 {
    public static void main(String[] args) {
        checkEvenOdd(11);
        checkEvenOdd(20);
    }

    public static void checkEvenOdd(int number) {
        if (number % 2 == 0) {
            System.out.println(number + " is even.");
        } else {
            System.out.println(number + " is odd.");
        }
    }
}