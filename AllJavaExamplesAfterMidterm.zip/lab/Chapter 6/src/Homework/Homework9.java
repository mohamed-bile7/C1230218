package Homework;

public class Homework9 {
    public static void main(String[] args) {
        double area = calculateRectangleArea(8.0, 5.5);
        System.out.println("Area of rectangle: " + area);
    }

    public static double calculateRectangleArea(double length, double width) {
        return length * width;
    }
}