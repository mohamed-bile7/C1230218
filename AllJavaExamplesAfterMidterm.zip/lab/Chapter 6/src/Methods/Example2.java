package Methods;

public class Example2 {
    static int x = 3;
    public static void main(String[] args) {
        int x = 1;

        System.out.println(x);

        Dosomething();
    }
    static void Dosomething(){
        int x = 2;
        System.out.println(x);
    }
}
