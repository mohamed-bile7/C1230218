package Methods;

public class SumMethod {
    public static void main(String[] args) {
//        int a = max(5, 6);
//        System.out.println("max: "+max(5,7));
        int n1 = 100, n2 = 50;
        System.out.println("max: " + max(n1, n2));
    }

    static int max(int num1, int num2) {
        if (num1 > num2) {
            return num1;
        } else {
            return num2;
        }
    }
}
