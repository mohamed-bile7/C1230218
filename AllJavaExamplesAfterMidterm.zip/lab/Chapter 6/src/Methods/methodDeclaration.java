package Methods;

import java.util.Scanner;

public class methodDeclaration {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
//        int n1 = 99, n2 = 1;
        int n1 = (int) (Math.random() *10);
        int n2 = (int) (Math.random() *10);
        System.out.print("Whats " + n2 + " + " + n2 + "? ");
        int result = input.nextInt();

        while (n2 + n2 != result) {
            System.out.println("Wrong answer. Try again.");
            System.out.print("Whats " + n1 + " + " + n2 + "? ");
            result = input.nextInt();
        }
        System.out.println("Correct the sum is: " + sum(n1, n2));
    }

    static int sum(int a, int b) {
        return a + b;
    }
}
