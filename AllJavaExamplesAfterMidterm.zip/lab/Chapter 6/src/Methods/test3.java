package Methods;

import java.util.Scanner;

public class test3 {
    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {

        double balance = 0;
        int option = 0;

        while (option != 4) {
            System.out.println("\n--- Banking Menu ---");
            System.out.println("1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. Check Balance");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            option = scanner.nextInt();

            if (option == 1) {
                balance = deposit(scanner, balance);
            } else if (option == 2) {
                balance = withdraw(scanner, balance);
            } else if (option == 3) {
                checkBalance(balance);
            } else if (option != 4) {
                System.out.println("Invalid option. Try again.");
            }
        }

        System.out.println("Banking system exited.");
    }

    static double deposit(Scanner scanner, double balance) {
        System.out.print("Enter deposit amount: ");
        double amount = scanner.nextDouble();
        balance += amount;
        System.out.println("Deposit successful.");
        return balance;
    }

    static double withdraw(Scanner scanner, double balance) {
        System.out.print("Enter withdrawal amount: ");
        double amount = scanner.nextDouble();
        if (amount > balance) {
            System.out.println("Insufficient funds!");
        } else {
            balance -= amount;
            System.out.println("Withdrawal successful.");
        }
        return balance;
    }

    static void checkBalance(double balance) {
        System.out.println("Current Balance: " + balance);
    }
}


