package assignment;

import java.util.Scanner;

public class Calculator {
    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        double result = 0;
        int choice = 0;

        while (choice != 5) {
            System.out.println("\n******************");
            System.out.println("CALCULATOR PROGRAM");
            System.out.println("******************");
            System.out.println("1. Addition");
            System.out.println("2. Subtraction");
            System.out.println("3. Multiplication");
            System.out.println("4. Division");
            System.out.println("5. Exit");
            System.out.println("******************");

            System.out.print("Enter your choice (1-5): ");
            choice = input.nextInt();

            if (choice >= 1 && choice <= 4) {
                System.out.print("Enter your first number: ");
                double num1 = input.nextInt();
                System.out.print("Enter your second number: ");
                double num2 = input.nextInt();

                switch (choice) {
                    case 1 -> result = add(num1, num2);
                    case 2 -> result = subtract(num1, num2);
                    case 3 -> result = multiply(num1, num2);
                    case 4 -> result = divide(num1, num2);
                }
                System.out.println("******************");
                System.out.println("Result: " + result);
            } else if (choice != 5) {
                System.out.println("Invalid choice. Try again.");
            }
        }
        System.out.println("See you again. BY.");
        input.close();
    }

    static double add(double num1, double num2) {
        return num1 + num2;
    }

    static double subtract(double num1, double num2) {
        if (num1 < num2){
            double temp = num1;
            num1 = num2;
            num2 = temp;
            return  temp;
        }
        else {
            return  num1 - num2;
        }
    }

    static double multiply(double num1, double num2) {
        return num1 * num2;
    }

    static double divide(double num1, double num2) {
        if (num2 == 0) {
            System.out.println("***************************");
            System.out.println("Error can't divide by zero.");
            return 0;
        } else {
            return num1 / num2;
        }

    }
}