package assignment;

import java.util.Scanner;

public class test {
    static Scanner input = new Scanner(System.in);
    static double balance = 1000;
    static String history = "";

    public static void main(String[] args) {
        boolean isRunning = true;
        int choice;

        System.out.println("Welcome to the Banking Program!");
        System.out.println("Initial balance: "+ balance);
        while (isRunning) {
            printMenu();

            System.out.print("Enter your choice (1-5): ");
            if (input.hasNext()) {
                choice = input.nextInt();
                input.nextInt();

                switch (choice) {
                    case 1 -> checkBalance();
                    case 2 -> {
                        double amount = deposit(input);
                        balance += amount;
                        if (amount > 0) {
                            String entry = String.format("Deposited $%.2f\n", amount);
                            history += entry;
                            System.out.print(entry);
                        }
                    }
                    case 3 -> {
                        double amount = withdraw(input);
                        balance -= amount;
                        if (amount > 0) {
                            String entry = String.format("Withdrew $%.2f\n", amount);
                            history += entry;
                            System.out.print(entry);
                        }
                    }
                    case 4 -> showHistory();
                    case 5 -> isRunning = false;
                    default -> System.out.println("Invalid choice. Please enter 1-5.");
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                input.next();
            }
        }

        System.out.println("Thank you. Have a nice day!");
        input.close();
    }

    static void printMenu() {
        System.out.println("***************");
        System.out.println("BANKING PROGRAM");
        System.out.println("***************");
        System.out.println("1. Show Balance");
        System.out.println("2. Deposit");
        System.out.println("3. Withdraw");
        System.out.println("4. Show Transaction History");
        System.out.println("5. Exit");
        System.out.println("***************");
    }

    static void checkBalance() {
        System.out.printf("Current Balance: $%.2f\n", balance);
    }

    static double deposit(Scanner sc) {
        System.out.print("Enter an amount to deposit: ");
        if (sc.hasNextDouble()) {
            double amount = sc.nextDouble();
            if (amount < 0) {
                System.out.println("Amount can't be negative.");
                return 0;
            }
            return amount;
        } else {
            System.out.println("Invalid input. Please enter a valid number.");
            sc.next(); // clear invalid input
            return 0;
        }
    }

    static double withdraw(Scanner sc) {
        System.out.print("Enter an amount to withdraw: ");
        if (sc.hasNextDouble()) {
            double amount = sc.nextDouble();
            if (amount < 0) {
                System.out.println("Amount can't be negative.");
                return 0;
            } else if (amount > balance) {
                System.out.println("Insufficient funds.");
                return 0;
            }
            return amount;
        } else {
            System.out.println("Invalid input. Please enter a valid number.");
            sc.next(); // clear invalid input
            return 0;
        }
    }

    static void showHistory() {
        System.out.println("***************");
        if (history.isEmpty()) {
            System.out.println("No transactions yet.");
        } else {
            System.out.println("Transaction History:");
            System.out.print(history);
        }
    }
}