import java.util.Scanner;

public class bank {
    static double balance = 1000;
    static String[] transactionHistory = new String[100];
    static int historyCount = 0;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to Batman Bank: ");
        System.out.println("Your current balance: " + balance);

        boolean isRunning = true;
        int choice;

        while (isRunning) {
            showMenu();
            if (input.hasNextInt()){
                choice = input.nextInt();

                switch (choice) {
                    case 1 -> checkBalance();
                    case 2 -> deposit(input);
                    case 3 -> withdraw(input);
                    case 4 -> showHistory();
                    case 5 -> {
                        System.out.println("Thanks for using the bank!");
                        isRunning = false;
                    }
                    default ->
                            System.out.println("Invalid choice. Enter 1-5: ");
                }
            } else {
                System.out.println("Enter a number: ");
                input.next();
            }



        }
    }

    static void showMenu() {
        System.out.println("\n1. Check Balance");
        System.out.println("2. Deposit");
        System.out.println("3. Withdraw");
        System.out.println("4. Show History");
        System.out.println("5. Exit");
        System.out.print("Choose an option: ");
    }

    static void checkBalance() {
        System.out.println("Balance: $" + balance);
    }

    static void deposit(Scanner input) {
        System.out.print("Amount to deposit: ");
        double amount;
        if (input.hasNextDouble()){
            amount = input.nextDouble();
            if (amount > 0) {
                balance += amount;
                saveHistory("Deposited $" + amount);
                System.out.println("Deposited $" + amount);
            } else {
                System.out.println("Invalid amount.");
            }
        } else {
            System.out.println("Enter a number: ");
            input.next();
        }
    }

    static void withdraw(Scanner input) {
        System.out.print("Amount to withdraw: ");
        double amount;
        if (input.hasNextDouble()){
            amount = input.nextDouble();
            if (amount > 0 && amount <= balance) {
                balance -= amount;
                saveHistory("Withdrew $" + amount);
                System.out.println("Withdrew $" + amount);
            } else {
                System.out.println("Invalid or insufficient balance.");
            }
        } else {
            System.out.println("Enter a number: ");
            input.next();
        }
    }

    static void showHistory() {
        if (historyCount == 0) {
            System.out.println("No history.");
        } else {
            for (int i = 0; i < historyCount; i++) {
                System.out.println(transactionHistory[i]);
            }
        }
    }

    static void saveHistory(String text) {
        if (historyCount < 100) {
            transactionHistory[historyCount] = text;
            historyCount++;
        }
    }
}
//text, saveHistory, historyCount, history,