package package1;

public class max {
    public static void main(String[] args) {

    }

    public static int testmax(int a, int b) {
        if (a > b) {
            return a;
        } else {
            return b;
        }
    }
}
