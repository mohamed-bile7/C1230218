package package2;

import java.util.Scanner;

public class CalculatorProgram {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double result = 0;
        int choice = 0;

        while (choice !=5){
            System.out.println("\nCalculator Program");
            System.out.println("1. Addition");
            System.out.println("2. Subtraction");
            System.out.println("3. Multiplication");
            System.out.println("4. Division");
            System.out.println("5. Exit");

            System.out.print("Enter your choice: ");
            choice = input.nextInt();

            if (choice >= 1 && choice <=4){
                System.out.print("Enter your first number: ");
                double num1 = input.nextInt();
                System.out.print("Enter your second number: ");
                double num2 = input.nextInt();

                switch (choice){
                    case 1 -> result = add(num1,num2);
                    case 2 -> result = subtract(num1, num2);
                    case 3 -> result = multiply(num1,num2);
                    case 4 -> result = divide(num1,num2);
                }
                System.out.print("Result: "+ result);
            } else if (choice != 5) {
                System.out.println("Invalid choice. Try again.");
            }
        }
        System.out.println("Program existed!");
        input.close();
    }
    static double add(double num1, double num2){
        return  num1 + num2;
    }

    static double subtract(double num1, double num2){
        return num1 - num2;
    }

    static double multiply(double num1, double num2){
        return num1 * num2;
    }

    static double divide(double num1, double num2){
        if (num2 == 0){
            System.out.println("can't divide by 0");
            return 0;
        }
        else {
            return num1 / num2;
        }
    }
}



































