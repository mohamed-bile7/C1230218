package package2;

import package1.max;

public class test {
    public static void main(String[] args) {
        int x = 100;
        int y = 200;
        int result = max.testmax(y,x);
        System.out.println(result);
    }
}
