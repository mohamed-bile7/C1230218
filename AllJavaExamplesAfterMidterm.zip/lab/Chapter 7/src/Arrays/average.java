package Arrays;

public class average {
    public static void main(String[] args) {
        int[] marks = {100, 99, 89, 90, 96};
        int sum = 0;
        for (int score : marks) {
            sum += score;
        }

        double average = (double) sum / marks.length;
        System.out.println("Average: " + average);

        System.out.println("\nMarks above average: ");
        for (int num : marks) {
            if (num > average)
                System.out.println(num);
        }
    }
}
