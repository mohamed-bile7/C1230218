package Arrays;

public class products {
    public static void main(String[] args) {
        String[] products = {"lemon", "tomato", "canjero", "mufo", "soor",
                "caan", "baasto", "baris", "subag", "malab"};

        System.out.println(products.length);

        for (String product : products) {
            System.out.print(product + " ");
        }

    }
}
