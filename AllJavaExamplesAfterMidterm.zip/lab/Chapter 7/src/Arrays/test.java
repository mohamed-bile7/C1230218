package Arrays;

public class test {
    public static void main(String[] args) {
        // Array initializer
        int[] myList = {19, 20, 21, 32, 24, 25};

        int max = myList[0];

        for (int i = 1; i < myList.length; i++) {

            if (myList[i] > max) {

                max = myList[i];
            }
        }

        // 5. Print the final result.
        System.out.println("The largest number in the array is: " + max);
    }
}