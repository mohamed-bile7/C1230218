package Arrays;

public class test2 {
    public static void main(String[] args) {
        //declaration
//        char[] myList = new char[5];
//        myList[0] = 'a';
//        myList[1] = 'b';
//        myList[2] = 'c';
//        myList[3] = 'd';
//        myList[4] = 'e';
//        System.out.println(myList[0]);
//        System.out.println(myList.length);

        String[] name = {"a", "b", "c", "d", "e"};
        System.out.println(name.length);
        System.out.println(name[0]);
        System.out.println(name[1]);
        System.out.println(name[2]);
        System.out.println(name[3]);
        System.out.println(name[0]);

    }
}
