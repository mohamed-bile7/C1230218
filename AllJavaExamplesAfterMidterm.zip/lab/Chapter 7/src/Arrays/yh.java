package Arrays;

public class yh {
    public static void main(String[] args) {
        //declaration
//        double[] myList;
        //creation
//        myList = new double[5];
        //array initializer
        int[] myList = {19,20,21,32,24,25};


        System.out.println(myList[0]);
        System.out.println(myList.length);
    }
}
