package Practice;

import java.util.Arrays;

public class p1 {
    public static void main(String[] args) {
        char[] cars = {'a', 'A', '4', 'D', 'p'};
        Arrays.sort(cars);
        for (int c : cars){
            System.out.println(c);
        }
    }
}
