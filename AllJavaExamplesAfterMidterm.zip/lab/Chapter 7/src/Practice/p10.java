package Practice;

import java.util.Scanner;

public class p10 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] students;
        int size;
        System.out.print("How many students are in the class: ");
        size = input.nextInt();
        input.nextLine();
        students = new String[size];

        for (int i = 0; i < students.length; i++) {
            System.out.print("Enter name for student #" + (i + 1) + ": ");
            students[i] = input.nextLine();
        }

        for (int i = students.length - 1; i >= 0; i--) {
            System.out.println(students[i]);
        }
    }
}
