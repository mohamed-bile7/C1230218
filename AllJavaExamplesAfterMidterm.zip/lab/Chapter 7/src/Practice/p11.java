package Practice;

public class p11 {
    public static void main(String[] args) {
        int[] rolls = new int[2];
        int sum = 0;

        for (int i = 0; i < rolls.length; i++) {
            int diceRoll = (int) (Math.random() * 7);
            rolls[i] = diceRoll;
        }

        for (int roll : rolls) {
            sum += roll;
        }
        System.out.println("The total sum of all rolls were: "+sum);

    }
}
