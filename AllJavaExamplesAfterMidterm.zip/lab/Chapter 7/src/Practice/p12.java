package Practice;

import java.util.Scanner;

public class p12 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] rolls;
        int size;
        int total = 0;

        System.out.print("What # of dice do you want to roll? ");
        size = input.nextInt();
        input.nextLine();

        rolls = new int[size];

        for (int i = 0; i < rolls.length; i++) {
            int diceRoll = (int) (Math.random() * 6) + 1;
            System.out.println("- You rolled: " + diceRoll);
            total += diceRoll;
        }
        System.out.println("- Total dice roll was: " + total);

    }
}
