package Practice;

public class p14 {
    public static void main(String[] args) {
        int[] numbers = {19, 20, 21, 32, 24, 25};

        for (int i = 0; i<numbers.length; i++){
            int total = (int) (Math.random() * numbers.length);
            numbers[i] = total;
        }

        for (int sum :numbers){
            System.out.println(sum);
        }

    }
}
