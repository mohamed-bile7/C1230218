package Practice;

public class p15 {
    public static void main(String[] args) {
        int[] maxnum = {19, 28,29,39,90};

        int max = maxnum[0];

        for (int i = 1; i < maxnum.length; i++) {

            if (maxnum[i] > max) {

                max = maxnum[i];
            }
        }
        System.out.println("The largest number in the array is: " + max);
    }
}
