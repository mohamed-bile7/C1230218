package Practice;

public class p16 {
    public static void main(String[] args) {
        int[] numbers = {1,2,3,4};

        int swap = numbers[0];

        for (int i = 1; i< numbers.length; i++){
            numbers[i - 1] = numbers[i];
        }
        numbers[numbers.length - 1] = swap;

        for (int all : numbers){
            System.out.print(all + " ");
        }
    }
}
