package Practice;

public class p17 {
    public static void main(String[] args) {
        int[] sourcearrays = {2,3,4,5,6};
        int[] targetarray = new int[sourcearrays.length];

        for (int i = 0; i < sourcearrays.length; i++){
            targetarray[i] = sourcearrays[i];
        }
        for (int target : targetarray){
            System.out.println(target);
        }
    }
}
