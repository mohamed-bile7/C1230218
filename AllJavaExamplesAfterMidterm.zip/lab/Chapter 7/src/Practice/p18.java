package Practice;

public class p18 {
    public static void main(String[] args) {
        int[] numbers = {9, 8, 7, 0, 6, 3, 2};
        int searh1 = search(numbers, 1);
        System.out.println("Element found at index: " + searh1);
    }

    static int search(int[] numbers, int target) {
        for (int i = 0; i < numbers.length; i++)
            if (target == numbers[i])
                return i;
        return -1;
    }
}
