package Practice;


import java.util.Scanner;

public class p2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] foods;
        int size;

        System.out.print("What # of food do you want: ");
        size = input.nextInt();
        input.nextLine();

        foods = new String[size];

        for (int i = 0; i < foods.length; i++) {
            System.out.print("Enter a food: ");
            foods[i] = input.nextLine();
        }

        // : means every food in foods {do whats inside this}
        for (String food : foods) {
            System.out.println(food);
        }
    }
}
