package Practice;


public class p3 {
    public static void main(String[] args) {
        int[] numbers = {9, 8, 7, 0, 6, 3, 2};
        int target = 3;
        boolean isFound = false;

        for (int i = 0; i < numbers.length; i++) {
            if (target == numbers[i]) {
                System.out.println("Element found at index: " + i);
                isFound = true;
            }
        }
        if (!isFound) {
            System.out.println("Element not found in the array");
        }
    }
}
