package Practice;

import java.util.Arrays;
import java.util.Scanner;

public class p4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] fruits = {"Apple", "banana", "see food"};


        boolean isFound = false;

        String searcharray;

        System.out.print("Enter a fruit to search for: ");
        searcharray = input.nextLine();

        for (int i = 0; i < fruits.length; i++) {
            if (searcharray.equals(fruits[i])) {
                System.out.println("Element found at index: " + i);
                isFound = true;
                break;
            }
        }


        if (!isFound) {
            System.out.println("Element not found in the array, try again");
            input.nextLine();
        }

    }
}
