package Practice;

public class p6 {
    public static void main(String[] args) {
        String[][] playerss = {{"Ronaldo", "Antony", "Mpabbe"},
                               {"Haaland", "Rodrygo", "Vinicius"},
                               {"Gernacho", "Salah", "Rafael Leo" }};

        playerss[2][1] = "Mane";
        playerss[1][0] = "Mpabbe";
        playerss[0][2] = "Zidane";
        for (String[] players : playerss ){
            for (String player : players){
                System.out.println(player + " ");
            }
        }
    }
}
