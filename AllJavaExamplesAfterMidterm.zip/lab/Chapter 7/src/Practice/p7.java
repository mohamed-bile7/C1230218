package Practice;

public class p7 {
    public static void main(String[] args) {
        char[][] telephone = {{'1', '2', '3'},
                              {'4', '5', '6'},
                              {'7', '8', '9'},
                              {'*', '0', '#'}};

        for (char[] phone : telephone){
            for (char phoneNumbers : phone){
                System.out.print(phoneNumbers + " ");
            }
            System.out.println();
        }
    }
}
