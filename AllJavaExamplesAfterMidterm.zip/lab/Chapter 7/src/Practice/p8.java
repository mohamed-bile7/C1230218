package Practice;

public class p8 {
    public static void main(String[] args) {
        String[] foods = {"Rooti iyo Beer", "Federation", "Pasto Alfardo", "Bariis Sab",
                "Muufo iyo Maraq", "Malawax", "Suqaar iyo sabayad", "Canjero"};

        String[][] menu = {{"Rooti iyo Beer", "Federation"}, {"Pasto Alfardo", "Bariis Sab"},
                           {"Muufo iyo Maraq", "Malawax"}, {"Suqaar iyo sabayad", "Canjero"}};

        System.out.println("Our Menu:\n");
        for (String[] me_nu : menu) {
            for (String myMenu : me_nu) {
                System.out.print("- " + myMenu + "  " + " ");
            }
            System.out.println();
        }

        System.out.println("\nPicking a random food for you to eat...");

        int randomIndex = (int) (Math.random() * foods.length);
        String chosenFood = foods[randomIndex];
        System.out.println("\nOur suggestion: You should eat " + chosenFood + "!");
    }
}
