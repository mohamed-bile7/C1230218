package Practice;

import java.util.Arrays;

public class p9 {
    public static void main(String[] args) {
        String[] foods = {"Rooti iyo Beer", "A", "a", "Federation", "Pasto Alfardo", "Bariis Sab",
                "Muufo iyo Maraq", "Malawax", "Suqaar iyo sabayad", "Canjero"};
        Arrays.sort(foods);
        System.out.println("*********");
        System.out.println("Our Menu:");
        System.out.println("*********\n");
        for (String menu : foods){
            System.out.print("- " + menu + "  ");
            System.out.println();
        }

        System.out.println("\nPicking a random food for you to eat...");

        int randomIndex = (int) (Math.random() * foods.length);
        String chosenFood = foods[randomIndex];
        System.out.println("\nOur suggestion: You should eat " + chosenFood + "!");
    }
}
