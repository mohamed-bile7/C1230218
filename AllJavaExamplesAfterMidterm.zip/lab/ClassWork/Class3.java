package ClassWork;

import java.util.Scanner;

public class Class3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a number between 1 and 10: ");
        int answer = input.nextInt();
        for (; answer < 1 || answer > 10;){
            System.out.println(answer +" is not between 1 and 10");
            answer = input.nextInt();
        }
        System.out.println(answer +" is between 1 and 10.");
    }

}

